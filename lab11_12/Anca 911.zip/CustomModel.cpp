#include "CustomModel.h"



CustomModel::CustomModel(Repository& c): contr{c}
{
}


CustomModel::~CustomModel()
{
}

int CustomModel::rowCount(const QModelIndex & parent) const
{
	return contr.getAll().size();
}

int CustomModel::columnCount(const QModelIndex & parent) const
{
	return 4;
}

QVariant CustomModel::data(const QModelIndex & index, int role) const
{
	int row = index.row();
	int col = index.column();
	Cat kitty = contr.getAll()[row];
	QString img = QString::fromStdString(kitty.get_photo());
	QPixmap pixmap(img);
	if (role == Qt::DisplayRole)
	{
		switch (col)
		{
		case 0:
			return QString::fromStdString(kitty.get_name());
		/*case 1:
		{
			
			return QPixmap(img);
		}*/
		case 2:
			return QString::fromStdString(kitty.get_breed());
		case 3:
			return QString::number(kitty.get_age());
		default:
			break;
		}
	}
	if (role == Qt::DecorationRole)
		if (col == 1)
			return pixmap;
	if (role == Qt::SizeHintRole)
		if (col == 1)
			return pixmap.size();
	return QVariant();
}

QVariant CustomModel::headerData(int section, Qt::Orientation orientation, int role) const
{
	if (orientation == Qt::Horizontal && role == Qt::DisplayRole)
	{
		switch (section)
		{
		case 0:
			return "Name";
		case 1:
			return "Photo";
		case 2:
			return "Breed";
		case 3:
			return "Age";
		default:
			break;
		}
	}
	return QVariant();
}

bool CustomModel::setData(const QModelIndex & index, const QVariant & value, int role)
{
	int row = index.row();
	int col = index.column();
	Cat kitty = contr.getAll()[row];
	if (role == Qt::EditRole)
	{
		switch (col)
		{
		case 0:
			kitty.set_name(value.toString().toStdString());
			break;
		case 1:
			kitty.set_photo(contr.getAll()[row].get_photo());
			break;
		case 2:
			kitty.set_breed(value.toString().toStdString());
			break;
		case 3:
			kitty.set_age(value.toString().toInt());
			break;
		default:
			break;
		}
	}
	emit dataChanged(index, index);
	return false;
}

Qt::ItemFlags CustomModel::flags(const QModelIndex & index) const
{
	return Qt::ItemIsEditable | QAbstractTableModel::flags(index);
}
