#include "ChoiceGUI.h"



ChoiceGUI::ChoiceGUI()
{
	QHBoxLayout *layout = new QHBoxLayout{ this };
	this->csv = new QPushButton{ "CSV File" };
	this->html = new QPushButton{ "HTML File" };
	layout->addWidget(this->csv);
	layout->addWidget(this->html);
	QObject::connect(this->csv, &QPushButton::clicked, this, &ChoiceGUI::handleCSV);
	QObject::connect(this->html, &QPushButton::clicked, this, &ChoiceGUI::handleHTML);
}


ChoiceGUI::~ChoiceGUI()
{
}

void ChoiceGUI::handleCSV()
{
	RepositoryCSV adoption{"database.csv"};
	RepositoryTextFile repo{ "database.txt" };
	Controller c{ repo, adoption };
	MainWindow w{ c };
	w.show();
}

void ChoiceGUI::handleHTML()
{
	RepositoryHTML adoption{ "database.html" };
	RepositoryTextFile repo{ "database.txt" };
	Controller c{ repo, adoption };
	MainWindow w{ c };
	w.show();
}
