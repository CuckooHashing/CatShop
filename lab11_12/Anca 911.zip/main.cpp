#include "lab11_12.h"
#include <QtWidgets/QApplication>
#include <iostream>
#include "Cat.h"
#include "Controller.h"
#include "RepositoryCSV.h"
#include "RepositoryHTML.h"
#include "RepositoryTextFile.h"
#include "CatException.h"
#include "MainWindow.h"
#include "CustomModel.h"

int main(int argc, char *argv[])
{
	QApplication a(argc, argv);
	RepositoryTextFile r{ "database.txt" };
	RepositoryCSV ad{ "file.csv" };
	CustomModel* m = new CustomModel{ ad };
	Controller c{ r, ad };
	//GUI w{ c };
	MainWindow w{c, m};
	w.show();
	return a.exec();
}
