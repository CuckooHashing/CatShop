#pragma once
#include "Repository.h"
class RepositoryTextFile :
	public Repository
{
private:
	std::string filename = "database.txt";
	std::vector<Cat> list;
public:
	RepositoryTextFile(std::string file);
	void add(const Cat& kitty) override;
	void remove(const Cat& kitty) override;
	void update(const Cat& chat, const Cat& kitty) override;
	Cat get_cat(int pos) override;
	int getSize() override;
	void print() override;
	void save() override;
	void load() override;
	void open() override;
	std::vector<Cat> getAll() override;
	~RepositoryTextFile();
};

