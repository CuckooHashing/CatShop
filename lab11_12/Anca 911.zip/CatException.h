#pragma once
#include <exception>
#include <string>
class CatException :
	public std::exception
{
private:
	std::string e;
public:
	CatException(const std::string& error) : e{ error } {}
	virtual const char*  what() const throw()
	{
		return e.c_str();
	}
};

