#pragma once
#include "Cat.h"
#include <vector>
#include <fstream>
#include <Windows.h>

class Repository
{
private:
	std::vector<Cat> list;
	std::string filename = "database.txt";
public:
	//Repository();
	virtual void add(const Cat& kitty) = 0;
	virtual void remove(const Cat& kitty) = 0;
	virtual void update(const Cat& chat, const Cat& kitty) = 0;
	virtual Cat get_cat(int pos) = 0;
	virtual int getSize() = 0;
	virtual ~Repository() {};
	virtual void print() = 0;
	virtual void save() = 0;
	virtual void load() = 0;
	virtual void open() = 0;
	virtual std::vector<Cat> getAll() = 0;
};

