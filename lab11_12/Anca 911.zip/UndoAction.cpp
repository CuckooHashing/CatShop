#include "UndoAction.h"



UndoAction::UndoAction()
{
}


UndoAction::~UndoAction()
{
}

UndoAdd::UndoAdd(Cat s, Repository &r): UndoAction{}, addedCat{s}, repo{r}
{
}

void UndoAdd::executeUndo()
{

	//do something
	// toata abordarea ii numai sa apelam functia opusa din repo
	repo.remove(addedCat);

}

UndoAdd::~UndoAdd()
{
}

UndoRemove::UndoRemove(Cat s, Repository &r):UndoAction{}, deletedCat{s}, repo{r}
{
}

void UndoRemove::executeUndo()
{
	//same ca la add
	repo.add(deletedCat);
}

UndoRemove::~UndoRemove()
{
}

UndoUpdate::UndoUpdate(Cat s, Cat ss, Repository & r) :UndoAction{}, updatedCat{ s }, oldCat{ss}, repo{ r }
{
}

void UndoUpdate::executeUndo()
{
	repo.update(updatedCat, oldCat);
}

UndoUpdate::~UndoUpdate()
{
}
