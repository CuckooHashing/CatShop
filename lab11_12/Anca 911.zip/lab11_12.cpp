#include "lab11_12.h"


GUI::GUI(Controller & c): contr{c}
{
	this->create();
	this->populate(this->contr.getAll());
	QObject::connect(this->filter, &QLineEdit::textChanged, this, &GUI::filtered);
	QObject::connect(this->addCat, &QPushButton::clicked, this, &GUI::triggerAdd);
	QObject::connect(this->removeCat, &QPushButton::clicked, this, &GUI::triggerRemove);
	QObject::connect(this->updateCat, &QPushButton::clicked, this, &GUI::triggerUpdate);
	QObject::connect(this->stats, &QPushButton::clicked, this, &GUI::triggerStats);
	QObject::connect(this->undoButton, &QPushButton::clicked, this, &GUI::CtrZ);
	QObject::connect(this->redoButton, &QPushButton::clicked, this, &GUI::CtrR);
	QObject::connect(this->undoTrigger, &QShortcut::activated, this, &GUI::CtrZ);
	QObject::connect(this->redoTrigger, &QShortcut::activated, this, &GUI::CtrR);
	this->setStyleSheet("* {color: qlineargradient(spread:pad, x1:0 y1:0, x2:1 y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"
		"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 lightsteelblue, stop:1 grey);}");
}

void GUI::create()
{
	QHBoxLayout *layout = new QHBoxLayout{ this };
	this->cats = new QListWidget();
	QVBoxLayout *leftLayout = new QVBoxLayout{};
	this->filter = new QLineEdit{};
	leftLayout->addWidget(filter);
	leftLayout->addWidget(this->cats);
	layout->addLayout(leftLayout);
	QVBoxLayout* rightLayout = new QVBoxLayout{};
	QHBoxLayout* buttonsLayout = new QHBoxLayout{};
	QFormLayout* catData = new QFormLayout{};
	this->name = new QLineEdit{};
	this->breed = new QLineEdit{};
	this->age = new QLineEdit{};
	catData->addRow("Name", this->name);
	catData->addRow("Breed", this->breed);
	catData->addRow("Age", this->age);
	rightLayout->addLayout(catData);
	this->addCat = new QPushButton{ "Add" };
	this->removeCat = new QPushButton{ "Remove" };
	this->updateCat = new QPushButton{ "Update" };
	this->stats = new QPushButton{ "Stats" };
	buttonsLayout->addWidget(addCat);
	buttonsLayout->addWidget(removeCat);
	buttonsLayout->addWidget(updateCat);
	buttonsLayout->addWidget(stats);
	QHBoxLayout* buttonsLayout2 = new QHBoxLayout{};
	this->undoButton = new QPushButton{ "Undo" };
	this->redoButton = new QPushButton{ "Redo" };
	buttonsLayout2->addWidget(undoButton);
	buttonsLayout2->addWidget(redoButton);
	rightLayout->addLayout(buttonsLayout);
	rightLayout->addLayout(buttonsLayout2);
	layout->addLayout(rightLayout);
	this->undoTrigger = new QShortcut{this};
	this->redoTrigger = new QShortcut{ this };
	this->undoTrigger->setKey(QKeySequence("Ctrl+Z"));
	this->redoTrigger->setKey(QKeySequence("Ctrl+R"));

}

void GUI::populate(std::vector<Cat> kitties)
{
	this->cats->clear();
	
	for (auto kat : kitties)
	{
		QString string = QString::fromStdString(kat.form());
		this->cats->addItem(string);
	}
}

void GUI::triggerAdd()
{
	contr.add(this->name->text().toStdString(), this->breed->text().toStdString(), "dummy dragon", stoi(this->age->text().toStdString()));
	this->populate(this->contr.getAll());
}

void GUI::triggerRemove()
{
	contr.remove(this->name->text().toStdString(), this->breed->text().toStdString(), "dummy dragon", stoi(this->age->text().toStdString()));
	this->populate(this->contr.getAll());
}

void GUI::triggerUpdate()
{
	int current = this->cats->currentRow();
	Cat kitty = contr.getAll()[current];
	contr.update(kitty.get_name(), kitty.get_breed(), kitty.get_photo(), kitty.get_age(), this->name->text().toStdString(), this->breed->text().toStdString(), kitty.get_photo(), stoi(this->age->text().toStdString()));
	this->populate(this->contr.getAll());
}

void GUI::triggerStats()
{
	QMainWindow *w = new QMainWindow{};
	std::vector<std::string> breeds;
	std::vector<int> ap;
	int i = 0;
	for (auto kat : this->contr.getAll())
	{
		bool oke = false;
		for (auto bred : breeds)
		{
			if (bred == kat.get_breed())
			{
				ap[i]++;
				oke = true;
			}
		}
		if (oke == false)
		{
			breeds.push_back(kat.get_breed());
			ap.push_back(1);
		}
	}
	std::vector<QBarSet*> stat;
	i = 0;
	for (auto bred : breeds)
	{
		QBarSet* set = new QBarSet{ QString::fromStdString(bred) };
		*set << ap[i];
		i++;
		stat.push_back(set);
	}
	QBarSeries* series = new QBarSeries{};
	for (auto st : stat)
		series->append(st);
	QChart *chart = new QChart();
	chart->addSeries(series);
	chart->setTitle("Chart of cat breeds");
	chart->setAnimationOptions(QChart::SeriesAnimations);
	chart->legend()->setVisible(true);
	chart->legend()->setAlignment(Qt::AlignBottom);
	QChartView *chartView = new QChartView(chart);
	chartView->setRenderHint(QPainter::Antialiasing);
	w->setCentralWidget(chartView);
	w->resize(700, 500);
	w->show();
}

void GUI::CtrZ()
{
	this->contr.executeUndo();
	this->populate(contr.getAll());
}

void GUI::CtrR()
{
	this->contr.executeRedo();
	this->populate(contr.getAll());
}

void GUI::filtered()
{
	QString text = this->filter->text();
	this->cats->clear();
	populate(this->contr.filter(text.toStdString()));
}
