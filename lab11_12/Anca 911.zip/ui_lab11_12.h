/********************************************************************************
** Form generated from reading UI file 'lab11_12bnhzGH.ui'
**
** Created by: Qt User Interface Compiler version 5.12.3
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef LAB11_12BNHZGH_H
#define LAB11_12BNHZGH_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_lab11_12Class
{
public:
    QWidget *centralWidget;
    QVBoxLayout *verticalLayout_2;
    QVBoxLayout *verticalLayout;
    QPushButton *AdministratorMode;
    QPushButton *UserMode;
    QToolBar *mainToolBar;
    QStatusBar *statusBar;

    void setupUi(QMainWindow *lab11_12Class)
    {
        if (lab11_12Class->objectName().isEmpty())
            lab11_12Class->setObjectName(QString::fromUtf8("lab11_12Class"));
        lab11_12Class->resize(456, 286);
        centralWidget = new QWidget(lab11_12Class);
        centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
        verticalLayout_2 = new QVBoxLayout(centralWidget);
        verticalLayout_2->setSpacing(6);
        verticalLayout_2->setContentsMargins(11, 11, 11, 11);
        verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
        verticalLayout = new QVBoxLayout();
        verticalLayout->setSpacing(6);
        verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
        AdministratorMode = new QPushButton(centralWidget);
        AdministratorMode->setObjectName(QString::fromUtf8("AdministratorMode"));
        QFont font;
        font.setFamily(QString::fromUtf8("Adobe Caslon Pro Bold"));
        font.setPointSize(18);
        font.setBold(true);
        font.setWeight(75);
        AdministratorMode->setFont(font);
        AdministratorMode->setCursor(QCursor(Qt::BusyCursor));

        verticalLayout->addWidget(AdministratorMode);

        UserMode = new QPushButton(centralWidget);
        UserMode->setObjectName(QString::fromUtf8("UserMode"));
        UserMode->setFont(font);
        UserMode->setCursor(QCursor(Qt::ArrowCursor));

        verticalLayout->addWidget(UserMode);


        verticalLayout_2->addLayout(verticalLayout);

        lab11_12Class->setCentralWidget(centralWidget);
        mainToolBar = new QToolBar(lab11_12Class);
        mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
        lab11_12Class->addToolBar(Qt::TopToolBarArea, mainToolBar);
        statusBar = new QStatusBar(lab11_12Class);
        statusBar->setObjectName(QString::fromUtf8("statusBar"));
        lab11_12Class->setStatusBar(statusBar);

        retranslateUi(lab11_12Class);

        QMetaObject::connectSlotsByName(lab11_12Class);
    } // setupUi

    void retranslateUi(QMainWindow *lab11_12Class)
    {
        lab11_12Class->setWindowTitle(QApplication::translate("lab11_12Class", "lab11_12", nullptr));
        AdministratorMode->setText(QApplication::translate("lab11_12Class", "Administrator Mode", nullptr));
        UserMode->setText(QApplication::translate("lab11_12Class", "User Mode", nullptr));
    } // retranslateUi

};

namespace Ui {
    class lab11_12Class: public Ui_lab11_12Class {};
} // namespace Ui

QT_END_NAMESPACE

#endif // LAB11_12BNHZGH_H
