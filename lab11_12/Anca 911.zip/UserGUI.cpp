#include "UserGUI.h"



UserGUI::UserGUI(Controller &c, QAbstractItemModel* m): contr{c}, model{m}
{
	this->cats = this->contr.getAll();
	this->setupUi();
	this->pos = 0;
	this->showImage();
	QObject::connect(this->Next, &QPushButton::clicked, this, &UserGUI::nextCat);
	QObject::connect(this->Adopt, &QPushButton::clicked, this, &UserGUI::adoptCat);
	QObject::connect(this->ShowAdoption, &QPushButton::clicked, this, &UserGUI::seeList);
}


UserGUI::~UserGUI()
{
}

void UserGUI::showImage()
{
	std::string link = "<img src='" + this->cats[this->pos].get_photo() + "' />";
	this->CatPhoto->setText(QString::fromStdString(link));
	std::string info = "This cat is called " + this->cats[this->pos].get_name() + " and is " + std::to_string(this->cats[this->pos].get_age()) + " old.\nIts breed is " + this->cats[this->pos].get_breed() + ".";
	this->CatInfo->setText(QString::fromStdString(info));	
	this->setStyleSheet("* {color: qlineargradient(spread:pad, x1:0 y1:0, x2:1 y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"
		"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 lightsteelblue, stop:1 grey);}");
}

bool UserGUI::valid()
{
	return this->cats.size() > 0;
}

void UserGUI::nextCat()
{
	if (this->valid())
	{
		if (this->pos + 1 >= this->cats.size())
			this->pos = 0;
		else
			this->pos++;
		this->showImage();
	}
	else
	{
		this->CatPhoto->setText("You've adopted all cats :(");
		this->CatInfo->setText("You've adopted all cats :(");
	}
}

void UserGUI::adoptCat()
{
	this->contr.add_adoption(this->pos);
	std::vector<Cat>::iterator here = std::find(this->cats.begin(), this->cats.end(), this->cats[this->pos]);
	this->cats.erase(here);
}

void UserGUI::seeList()
{
	QWidget *w = new QWidget{};
	QHBoxLayout *layout = new QHBoxLayout{ w };
	this->adoption = new QTableView{};
	layout->addWidget(adoption);
	//CustomModel* m = new CustomModel{ contr.getAdoptionRepo() };
	adoption->setModel(this->model);
	adoption->resizeRowsToContents();
	adoption->resizeColumnsToContents();
	//adoption->setModel(m);
	/*QListView* adoption = new QListView{};
	layout->addWidget(adoption);
	for (auto kat : this->contr.getAdoption())
	{
		QString itemInList = QString::fromStdString(kat.toString());
		QFont font("Courier", 20, 10, true);
		adoption->setFont(font);
		adoption.add

	}*/
	w->show();
}
