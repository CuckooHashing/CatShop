#pragma once
#include "D:\Qt\5.12.3\msvc2017_64\include\QtWidgets\qwidget.h"
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QLabel>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "Controller.h"
#include "Cat.h"
#include <QListWidget>
#include <qtableview.h>
#include "CustomModel.h"

class UserGUI :
	public QWidget
{
private:
	QVBoxLayout *verticalLayout_2;
	QVBoxLayout *verticalLayout;
	QLabel *CatInfo;
	QLabel *CatPhoto;
	QHBoxLayout *horizontalLayout;
	QPushButton *Adopt;
	QPushButton *Next;
	QPushButton *Filter;
	QPushButton *ShowAdoption;
	QTableView* adoption;
	Controller &contr;
	QAbstractItemModel* model;
	std::vector<Cat> cats;
	int pos = 0;
public:
	UserGUI(Controller &c, QAbstractItemModel* m);
	void setupUi()
	{
		if (this->objectName().isEmpty())
			this->setObjectName(QString::fromUtf8("Form"));
		this->resize(554, 398);
		verticalLayout_2 = new QVBoxLayout(this);
		verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
		verticalLayout = new QVBoxLayout();
		verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
		CatInfo = new QLabel(this);
		CatInfo->setObjectName(QString::fromUtf8("CatInfo"));
		QFont font;
		font.setFamily(QString::fromUtf8("Adobe Caslon Pro Bold"));
		font.setPointSize(12);
		font.setBold(true);
		font.setWeight(75);
		CatInfo->setFont(font);

		verticalLayout->addWidget(CatInfo);

		CatPhoto = new QLabel(this);
		CatPhoto->setObjectName(QString::fromUtf8("CatPhoto"));

		verticalLayout->addWidget(CatPhoto);

		horizontalLayout = new QHBoxLayout();
		horizontalLayout->setObjectName(QString::fromUtf8("horizontalLayout"));
		Adopt = new QPushButton(this);
		Adopt->setObjectName(QString::fromUtf8("Adopt"));
		QFont font1;
		font1.setFamily(QString::fromUtf8("Adobe Caslon Pro Bold"));
		font1.setPointSize(18);
		font1.setBold(true);
		font1.setWeight(75);
		Adopt->setFont(font1);

		horizontalLayout->addWidget(Adopt);

		Next = new QPushButton(this);
		Next->setObjectName(QString::fromUtf8("Next"));
		Next->setFont(font1);

		horizontalLayout->addWidget(Next);

		Filter = new QPushButton(this);
		Filter->setObjectName(QString::fromUtf8("Filter"));
		Filter->setFont(font1);

		horizontalLayout->addWidget(Filter);

		ShowAdoption = new QPushButton(this);
		ShowAdoption->setObjectName(QString::fromUtf8("List"));
		ShowAdoption->setFont(font1);

		horizontalLayout->addWidget(ShowAdoption);


		verticalLayout->addLayout(horizontalLayout);


		verticalLayout_2->addLayout(verticalLayout);


		retranslateUi();

		QMetaObject::connectSlotsByName(this);
	} // setupUi

	void retranslateUi()
	{
		this->setWindowTitle(QApplication::translate("Form", "Form", nullptr));
		CatInfo->setText(QApplication::translate("Form", "This is the dummy text. It is here just to be.", nullptr));
		CatPhoto->setText(QApplication::translate("Form", "Photo here", nullptr));
		Adopt->setText(QApplication::translate("Form", "Adopt", nullptr));
		Next->setText(QApplication::translate("Form", "Next", nullptr));
		Filter->setText(QApplication::translate("Form", "Filter", nullptr));
		ShowAdoption->setText(QApplication::translate("Form", "List", nullptr));
	} // retranslateUi

	~UserGUI();

private:
	void showImage();
	bool valid();
	
private slots:
	void nextCat();
	void adoptCat();
	void seeList();

};

