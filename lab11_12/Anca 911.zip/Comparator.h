#pragma once
#include "Cat.h"
#include <string>
template <typename T>
class Comparator
{
public:
	virtual bool relation(T& a, T& b) = 0;
	virtual ~Comparator() {};
};


class ComparatorAscendingByName : public Comparator<Cat>
{
public:
	bool relation(Cat& a, Cat& b) override { return a.get_name() < b.get_name(); }
};

class ComparatorDescendingByAge : public Comparator<Cat>
{
public:
	bool relation(Cat& a, Cat& b) override { return a.get_age() > b.get_age();  }
};

