#pragma once
#include "D:\Qt\5.12.3\msvc2017_64\include\QtWidgets\qmainwindow.h"
#include "MainWindow.h"
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include "Controller.h"
#include "RepositoryCSV.h"
#include "RepositoryHTML.h"
#include "RepositoryTextFile.h"
class ChoiceGUI :
	public QMainWindow
{
private:
	QPushButton* csv, *html;
public:
	ChoiceGUI();
	~ChoiceGUI();
private slots:
	void handleCSV();
	void handleHTML();
};

