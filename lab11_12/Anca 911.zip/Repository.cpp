/*
#include "Repository.h"
#include <algorithm>
#include <exception>
#include <fstream>
//#include <boost/algorithm/string.hpp>



Repository::Repository()
{
	load();
}

void Repository::add(const Cat & kitty)
{
	list.push_back(kitty);
	save();
}

void Repository::remove(const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), kitty);
	if (here != list.cend())
	{
		list.erase(here);
	}
	else
	{
		throw "Cannot remove cat as it doesn't exist";
	}
	save();
}

void Repository::update(const Cat & chat, const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), chat);
	if (here != list.cend())
	{
		list.erase(here);
		list.push_back(kitty);
	}
	else
	{
		throw "Cannot update cat as it doesn't exit";
	}
	save();
}


Repository::~Repository()
{
}

void Repository::print()
{
	for (unsigned int i = 0; i < list.size(); i++)
	{
		list[i].picture();
		std::cout << list[i].toString();
	}
}

void Repository::save()
{
	std::ofstream fout(filename);
	for (unsigned int i = 0; i < list.size(); i++)
	{
		fout << list[i].get_name() << ";" << list[i].get_breed() << ";" << list[i].get_age() << ";" << list[i].get_photo() << ";\n";
	}
	fout.close();
}

void Repository::load()
{
	std::ifstream fin(filename);
	if (fin.is_open())
	{
		std::string line;
		while (getline(fin, line))
		{
			//boost::split(line, ";
			int count = 0;
			std::string name = line.substr(count, line.find(";"));
			count += name.size() + 1;
			line[line.find(";")] = ' ';

			std::string breed = line.substr(count, line.find(";") - count);
			count += breed.size() + 1;
			line[line.find(";")] = ' ';

			std::string age = line.substr(count, line.find(";") - count);
			count += age.size() + 1;
			line[line.find(";")] = ' ';

			std::string link = line.substr(count, line.find(";") - count);
			count += link.size() + 1;

			this->add(Cat(name, breed, link, atoi(age.c_str())));

		}
		fin.close();
	}
}

std::vector<Cat> Repository::getAll()
{
	return this->list;
}

Cat Repository::get_cat(int pos)
{
	return this->list[pos];
}

int Repository::getSize()
{
	return this->list.size();
}
*/