#pragma once
#include "Repository.h"
#include "Cat.h"
#include <string>
#include <sstream>
#include <iostream>
#include "Comparator.h"
#include "UndoAction.h"
#include <functional>

class Controller
{
private:
	Repository& repo;
	Repository& adoption;
	std::vector<std::unique_ptr<UndoAction>> undoList;
	std::vector<std::unique_ptr<UndoAction>> redoList;
	std::vector<std::unique_ptr<UndoAction>> redosList;
public:
	Controller(Repository& repo, Repository& ad);
	void add(const std::string& name, const std::string& breed, const std::string& photo, int age);
	void remove(const std::string& name, const std::string& breed, const std::string& photo, int age);
	void update(const std::string& name, const std::string& breed, const std::string& photo, int age, const std::string& new_name, const std::string& new_breed, const std::string& new_photo, int new_age);
	~Controller();
	void print();
	void add_stuff();
	void show_pets(int current);
	bool show_some_pets(int current, std::string& breed, int age);
	void add_adoption(int current);
	void print_adoption();
	void sortName();
	void sortAge();
	void executeUndo();
	void executeRedo();
	Repository& getAdoptionRepo() { return this->adoption; }
	std::vector<Cat> genericSort(Comparator<Cat>* comp, std::vector<Cat> cats);
	int size();
	std::vector<Cat> filter(std::string fil);
	std::vector<Cat> getAll() { return repo.getAll(); }
	std::vector<Cat> getAdoption() { return this->adoption.getAll(); }
};

