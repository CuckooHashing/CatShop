#pragma once

#include <QtWidgets/QMainWindow>
#include "ui_lab11_12.h"
#include <QHBoxLayout>
#include "Controller.h"
#include "Cat.h"
#include <QListWidget>
#include <QFormLayout>
#include <QLineEdit>
#include <QPushButton>
#include <QLayout>
#include <vector>
#include <QChart>
#include <QtCharts/QChartView>
#include <QtCharts/QBarSeries>
#include <QtCharts/QBarSet>
#include <QKeySequence>
#include <qshortcut.h>

QT_CHARTS_USE_NAMESPACE

class GUI : public QWidget
{
	//Q_OBJECT

private:
	Controller &contr;
	QListWidget *cats;
	QLineEdit *name, *breed, *age;
	QLineEdit *filter;
	QPushButton *addCat, *removeCat, *updateCat, *stats;
	QShortcut* undoTrigger;
	QShortcut* redoTrigger;
	QPushButton* undoButton, *redoButton;

public:
	//lab11_12(Controller &c, QWidget *parent = Q_NULLPTR);
	GUI(Controller& c);
	~GUI() {};

private:
	Ui::lab11_12Class ui;
	void create();
	void populate(std::vector<Cat> kitties);
private slots:
	void filtered();
	void triggerAdd();
	void triggerRemove();
	void triggerUpdate();
	void triggerStats();
	void CtrZ();
	void CtrR();
};
