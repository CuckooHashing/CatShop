#include "Controller.h"


Controller::Controller(Repository& repo, Repository& ad): repo{repo}, adoption{ad}
{
	this->add_stuff();
}

void Controller::add(const std::string & name, const std::string & breed, const std::string & photo, int age)
{
	repo.add(Cat(name, breed, photo, age));
	auto pt = std::make_unique<UndoAdd>(Cat(name, breed, photo, age), this->repo);
	this->undoList.push_back(std::move(pt));
	auto pot = std::make_unique<UndoRemove>(Cat(name, breed, photo, age), this->repo);
	this->redoList.push_back(std::move(pot));
}

void Controller::remove(const std::string & name, const std::string & breed, const std::string & photo, int age)
{
	repo.remove(Cat(name, breed, photo, age));
	auto pt = std::make_unique<UndoRemove>(Cat(name, breed, photo, age), this->repo);
	this->undoList.push_back(std::move(pt));
	auto pot = std::make_unique<UndoAdd>(Cat(name, breed, photo, age), this->repo);
	this->redoList.push_back(std::move(pot));
}

void Controller::update(const std::string & name, const std::string & breed, const std::string & photo, int age, const std::string & new_name, const std::string & new_breed, const std::string & new_photo, int new_age)
{
	repo.update(Cat(name, breed, photo, age), Cat(new_name, new_breed, new_photo, new_age));
	auto pt = std::make_unique<UndoUpdate>(Cat(new_name, new_breed, new_photo, new_age), Cat(name, breed, photo, age), this->repo);
	this->undoList.push_back(std::move(pt));

	auto pot = std::make_unique<UndoUpdate>(Cat(name, breed, photo, age), Cat(new_name, new_breed, new_photo, new_age), this->repo);
	this->redoList.push_back(std::move(pot));
}


Controller::~Controller()
{
}

void Controller::print()
{
	repo.print();
}

void Controller::add_stuff()
{

	Cat kitty;
	kitty = Cat("Katze", "Persian", "1.jpg", 2);
	repo.add(kitty);
	kitty = Cat("Ivan", "Russian Blue", "2.jpg", 5);
	repo.add(kitty);
	kitty = Cat("Dorel", "Norwegian Forest cat", "3.jpg", 9);
	repo.add(kitty);
	kitty = Cat("Nana", "Calico", "4.jpg", 10);
	repo.add(kitty);
	kitty = Cat("Calico", "Calico", "5.jpg", 1);
	repo.add(kitty);
	kitty = Cat("Chitty", "British Shorthair", "6.jpg", 2);
	repo.add(kitty);
	kitty = Cat("Addy", "Scottish Fold", "7.jpg", 4);
	repo.add(kitty);
	kitty = Cat("Europa", "Ragdoll", "8.jpg", 3);
	repo.add(kitty);
}

void Controller::show_pets(int current)
{
	std::cout << this->repo.get_cat(current).toString();
	this->repo.get_cat(current).picture();
}

bool Controller::show_some_pets(int current, std::string & breed, int age)
{
	Cat kitty = this->repo.get_cat(current);
	if (strcmp(breed.c_str(), "") == 0)
	{
		if (kitty.get_age() < age)
		{
			std::cout<<kitty.toString();
			return true;
		}
		else return false;
	}
	else
	{
		if (strcmp(breed.c_str(), kitty.get_breed().c_str()) == 0)
		{
			if (kitty.get_age() < age)
			{
				std::cout << kitty.toString();
				return true;
			}
			else return false;
		}
		else return false;
	}
}

void Controller::add_adoption(int current)
{
	adoption.add(this->repo.get_cat(current));
	repo.remove(this->repo.get_cat(current));
}


void Controller::print_adoption()
{
	adoption.open();
}

void Controller::sortName()
{
	ComparatorAscendingByName* comp = new ComparatorAscendingByName;
	std::vector<Cat> sorted = genericSort(comp, repo.getAll());
	for (int i = 0; i < sorted.size(); i++)
		std::cout << sorted[i].toString();
	delete comp;
}

void Controller::sortAge()
{
	ComparatorDescendingByAge* comp = new ComparatorDescendingByAge;
	std::vector<Cat> sorted = genericSort(comp, repo.getAll());
	for (int i = 0; i < sorted.size(); i++)
		std::cout << sorted[i].toString();
	delete comp;
}

void Controller::executeUndo()
{
	if (this->undoList.size() == 0)
		return;
	auto undo = std::move(this->undoList[this->undoList.size() - 1]);
	undoList.pop_back();
	auto redo = std::move(this->redoList[this->redoList.size() - 1]);
	this->redosList.push_back(std::move(redo));
	undo->executeUndo();
}

void Controller::executeRedo()
{
	if (this->redosList.size() == 0)
		return;
	auto undo = std::move(this->redosList[this->redosList.size() - 1]);
	redosList.pop_back();
	undo->executeUndo();
}


std::vector<Cat> Controller::genericSort(Comparator<Cat>* comp, std::vector<Cat> cats)
{
	std::vector<Cat> newCats;
	newCats = cats;
	for (int i = 0; i < newCats.size() - 1; i++)
	{
		for (int j = i + 1; j < newCats.size(); j++)
		{
			if (comp->relation(newCats[i], newCats[j]) == false)
			{
				Cat kitty;
				kitty = newCats[i];
				newCats[i] = newCats[j];
				newCats[j] = kitty;
			}
		}
	}
	return newCats;
}

int Controller::size()
{
	return this->repo.getSize();
}

std::vector<Cat> Controller::filter(std::string fil)
{
	std::vector<Cat> thing;
	for (auto i : this->getAll())
	{
		if(strstr(i.get_name().c_str(), fil.c_str()) || strstr(i.get_breed().c_str(), fil.c_str()) || strstr(std::to_string(i.get_age()).c_str(), fil.c_str()))
			thing.push_back(i);
	}
	return thing;
}
