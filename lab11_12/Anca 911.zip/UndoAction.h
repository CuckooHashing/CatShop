#pragma once
#include "Cat.h"
#include "Repository.h"
class UndoAction
{
public:
	UndoAction();
	virtual void executeUndo() = 0;
	virtual std::string type() = 0;
	virtual ~UndoAction();
};

class UndoAdd :public UndoAction
{
private:
	Cat addedCat;
	Repository &repo;
public:
	UndoAdd(Cat s, Repository &r);
	std::string type() { return "add"; }
	void executeUndo() override;
	~UndoAdd();
};
class UndoRemove :public UndoAction
{
private:
	Cat deletedCat;
	Repository &repo;
public:
	UndoRemove(Cat s, Repository &r);
	std::string type() { return "remove"; }
	void executeUndo() override;
	~UndoRemove();
};
class UndoUpdate :public UndoAction
{
private:
	Cat updatedCat;
	Cat oldCat;
	Repository &repo;
public:
	UndoUpdate(Cat s, Cat ss, Repository &r);
	std::string type() { return "update"; }
	void executeUndo() override;
	~UndoUpdate();
};

