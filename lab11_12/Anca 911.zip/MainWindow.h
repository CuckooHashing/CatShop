#pragma once
#include "D:\Qt\5.12.3\msvc2017_64\include\QtWidgets\qwidget.h"
#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QPushButton>
#include <QtWidgets/QStatusBar>
#include <QtWidgets/QToolBar>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>
#include <QCoreApplication>
#include "lab11_12.h"
#include "UserGUI.h"
#include <QLinearGradient>
class MainWindow :
	public QMainWindow
{
private:
	QWidget *centralWidget;
	QVBoxLayout *verticalLayout_2;
	QVBoxLayout *verticalLayout;
	QPushButton *AdministratorMode;
	QPushButton *UserMode;
	QToolBar *mainToolBar;
	QStatusBar *statusBar;
	Controller &contr;
	QAbstractItemModel* model;
public:
	MainWindow(Controller &c, QAbstractItemModel* m);
	void setupUi()
	{
		if (this->objectName().isEmpty())
			this->setObjectName(QString::fromUtf8("PetShop"));
		this->resize(456, 286);
		centralWidget = new QWidget(this);
		centralWidget->setObjectName(QString::fromUtf8("centralWidget"));
		verticalLayout_2 = new QVBoxLayout(centralWidget);
		verticalLayout_2->setSpacing(6);
		verticalLayout_2->setContentsMargins(11, 11, 11, 11);
		verticalLayout_2->setObjectName(QString::fromUtf8("verticalLayout_2"));
		verticalLayout = new QVBoxLayout();
		verticalLayout->setSpacing(6);
		verticalLayout->setObjectName(QString::fromUtf8("verticalLayout"));
		AdministratorMode = new QPushButton(centralWidget);
		AdministratorMode->setObjectName(QString::fromUtf8("AdministratorMode"));
		QFont font;
		font.setFamily(QString::fromUtf8("Adobe Caslon Pro Bold"));
		font.setPointSize(18);
		font.setBold(true);
		font.setWeight(75);
		AdministratorMode->setFont(font);
		AdministratorMode->setCursor(QCursor(Qt::BusyCursor));

		verticalLayout->addWidget(AdministratorMode);

		UserMode = new QPushButton(centralWidget);
		UserMode->setObjectName(QString::fromUtf8("UserMode"));
		UserMode->setFont(font);
		UserMode->setCursor(QCursor(Qt::ArrowCursor));

		verticalLayout->addWidget(UserMode);


		verticalLayout_2->addLayout(verticalLayout);

		this->setCentralWidget(centralWidget);
		mainToolBar = new QToolBar(this);
		mainToolBar->setObjectName(QString::fromUtf8("mainToolBar"));
		this->addToolBar(Qt::TopToolBarArea, mainToolBar);
		statusBar = new QStatusBar(this);
		statusBar->setObjectName(QString::fromUtf8("statusBar"));
		this->setStatusBar(statusBar);

		retranslateUi(this);

		QMetaObject::connectSlotsByName(this );
	} // setupUi
	void retranslateUi(QMainWindow *MainWindow)
	{
		MainWindow->setWindowTitle(QApplication::translate("MainWindow", "Adopt a cat", nullptr));
		AdministratorMode->setText(QApplication::translate("MainWindow", "Administrator Mode", nullptr));
		UserMode->setText(QApplication::translate("MainWindow", "User Mode", nullptr));
	} // retranslateUi

	~MainWindow();
private slots:
	void administrator();
	void user();
};

