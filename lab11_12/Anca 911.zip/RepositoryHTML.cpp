#include "RepositoryHTML.h"



RepositoryHTML::RepositoryHTML(std::string file): filename{file}
{
}
void RepositoryHTML::add(const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), kitty);
	if (here == list.cend())
		list.push_back(kitty);
	else
		throw "Cat already exits";
	save();
}

void RepositoryHTML::remove(const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), kitty);
	if (here != list.cend())
	{
		list.erase(here);
	}
	else
	{
		throw "Cannot remove cat as it doesn't exist";
	}
	save();
}

void RepositoryHTML::update(const Cat & chat, const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), chat);
	if (here != list.cend())
	{
		list.erase(here);
		list.push_back(kitty);
	}
	else
	{
		throw "Cannot update cat as it doesn't exit";
	}
	save();
}

Cat RepositoryHTML::get_cat(int pos)
{
	return this->list[pos];
}

int RepositoryHTML::getSize()
{
	return this->list.size();
}

void RepositoryHTML::print()
{
	for (unsigned int i = 0; i < list.size(); i++)
	{
		list[i].picture();
		std::cout << list[i].toString();
	}
}

void RepositoryHTML::save()
{
	std::ofstream fout(filename);
	fout << "<!DOCTYPE html>\n <html>\n <head>\n <title>Adoption list</title>\n </head> <body> <table border="<<char(34)<<"2"<<char(34) << ">\n <tr>\n <td>Name</td>\n <td>Breed</td>\n <td>Age</td>\n <td>Photo</td>\n </tr>";
	for (unsigned int i = 0; i < list.size(); i++)
	{
		fout << "<tr>\n" << "<td>" << list[i].get_name() << "</td>" << "<td>" << list[i].get_breed() << "</td>" << "<td>" << list[i].get_age() << "</td>" << "<td>><a href =" << char(34) << list[i].get_photo() << char(34) << "></td>" << "</tr>";
	}
	fout << "</table> </body> </html>";
	fout.close();
}

void RepositoryHTML::load()
{
}

std::vector<Cat> RepositoryHTML::getAll()
{
	return list;
}

void RepositoryHTML::open()
{
	ShellExecuteA(NULL, NULL, "chrome.exe", this->filename.c_str(), NULL, SW_SHOWMAXIMIZED);
}


RepositoryHTML::~RepositoryHTML()
{
}
