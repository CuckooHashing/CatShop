#include "RepositoryCSV.h"
#include <fstream>


RepositoryCSV::RepositoryCSV(std::string file): filename{file}
{
}

void RepositoryCSV::add(const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), kitty);
	if (here == list.cend())
		list.push_back(kitty);
	else
		throw "Cat already exits";
	save();
}

void RepositoryCSV::remove(const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), kitty);
	if (here != list.cend())
	{
		list.erase(here);
	}
	else
	{
		throw "Cannot remove cat as it doesn't exist";
	}
	save();
}

void RepositoryCSV::update(const Cat & chat, const Cat & kitty)
{
	std::vector<Cat>::iterator here = std::find(list.begin(), list.end(), chat);
	if (here != list.cend())
	{
		list.erase(here);
		list.push_back(kitty);
	}
	else
	{
		throw "Cannot update cat as it doesn't exit";
	}
	save();
}

Cat RepositoryCSV::get_cat(int pos)
{
	return this->list[pos];
}

int RepositoryCSV::getSize()
{
	return this->list.size();
}

void RepositoryCSV::print()
{
	for (unsigned int i = 0; i < list.size(); i++)
	{
		list[i].picture();
		std::cout << list[i].toString();
	}
}

void RepositoryCSV::save()
{
	std::ofstream fout(filename);
	for (unsigned int i = 0; i < list.size(); i++)
	{
		fout << list[i].get_name() << "," << list[i].get_breed() << "," << list[i].get_age() << "," << list[i].get_photo() << ",\n";
	}
	fout.close();
}

void RepositoryCSV::load()
{
	std::ofstream fout(filename);
	fout.close();
	std::ifstream fin(filename);
	if (fin.is_open())
	{
		std::string line;
		while (getline(fin, line))
		{
			int count = 0;
			std::string name = line.substr(count, line.find(","));
			count += name.size() + 1;
			line[line.find(",")] = ' ';

			std::string breed = line.substr(count, line.find(",") - count);
			count += breed.size() + 1;
			line[line.find(",")] = ' ';

			std::string age = line.substr(count, line.find(",") - count);
			count += age.size() + 1;
			line[line.find(",")] = ' ';

			std::string link = line.substr(count, line.find(",") - count);
			count += link.size() + 1;

			this->add(Cat(name, breed, link, atoi(age.c_str())));

		}
		fin.close();
	}
}

std::vector<Cat> RepositoryCSV::getAll()
{
	return list;
}

void RepositoryCSV::open()
{
	system(filename.c_str());
}


RepositoryCSV::~RepositoryCSV()
{
}
