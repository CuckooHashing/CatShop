#include "MainWindow.h"



MainWindow::MainWindow(Controller &c, QAbstractItemModel* m): contr{c}, model{m}
{
	this->setupUi();
	QObject::connect(this->AdministratorMode, &QPushButton::clicked, this, &MainWindow::administrator);
	QObject::connect(this->UserMode, &QPushButton::clicked, this, &MainWindow::user);
	this->setStyleSheet("* {color: qlineargradient(spread:pad, x1:0 y1:0, x2:1 y2:0, stop:0 rgba(0, 0, 0, 255), stop:1 rgba(255, 255, 255, 255));"
		"background: qlineargradient( x1:0 y1:0, x2:1 y2:0, stop:0 lightsteelblue, stop:1 grey);}");
} 


MainWindow::~MainWindow()
{
}

void MainWindow::administrator()
{
	GUI *w = new GUI{ this->contr };
	w->show();
}

void MainWindow::user()
{
	UserGUI*w = new UserGUI{ this->contr, this->model };
	w->show();
}


